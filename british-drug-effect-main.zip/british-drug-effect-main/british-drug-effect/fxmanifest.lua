-- Resource Metadata
fx_version 'cerulean'
games { 'rdr3', 'gta5' }

author 'SwayX'
description 'British Drug Effects'
version '1.1.1'

-- What to run
client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}